
Run the executable.

-----------------Controls--------------------

Uses standard fps controls.

WASD to move around.
Click and hold left mouse button to rotate.
Space and control to go up and down.